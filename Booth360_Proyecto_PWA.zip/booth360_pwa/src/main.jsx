import React from 'react';
import { createRoot } from 'react-dom/client';
import Booth360App from './Booth360App.jsx';
createRoot(document.getElementById('root')).render(<Booth360App />);